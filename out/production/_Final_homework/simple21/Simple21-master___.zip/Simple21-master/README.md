# Simple21
Welcome to Simple 21! You'll play against 3 other players (computers). Try to get as close to 21 as possible, without going over.
